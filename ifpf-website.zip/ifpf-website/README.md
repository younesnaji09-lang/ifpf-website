# 🇫🇷 IFPF — Institut de Formation Professionnelle de France

Site web officiel de l'**Institut de Formation Professionnelle de France (IFPF)** — un site professionnel, responsive, moderne et optimisé pour l'hébergement **LWS**.

---

## 📑 Table des matières

1. [Présentation du site](#-présentation-du-site)
2. [Structure des fichiers](#-structure-des-fichiers)
3. [Pages du site](#-pages-du-site)
4. [Hébergement sur LWS (guide complet)](#-hébergement-sur-lws-guide-complet)
5. [Personnalisation](#-personnalisation-du-site)
6. [Maintenance & mises à jour](#-maintenance--mises-à-jour)
7. [Support](#-support)

---

## 🎯 Présentation du site

Ce site a été conçu pour mettre en valeur l'IFPF et ses **4 formations phares** :

- 🛒 **Employé Commercial** (Niveau CAP)
- 📊 **Assistant Commercial** (Niveau Bac)
- 📦 **Préparateur de Commande** (Niveau CAP)
- 💼 **Conseiller de Vente** (Niveau Bac)

### Caractéristiques techniques

- ✅ **100 % responsive** (mobile, tablette, desktop)
- ✅ **HTML5 + CSS3 + JavaScript vanilla** — aucune dépendance, rapide à charger
- ✅ **Design aux couleurs du drapeau français** (Bleu #0055A4 / Blanc #FFFFFF / Rouge #EF4135)
- ✅ **Polices Google Fonts** (Playfair Display + Montserrat) chargées via CDN
- ✅ **SEO optimisé** (meta descriptions, meta keywords, titre dédié par page, favicon)
- ✅ **Accessibilité** (attributs ARIA, contraste, navigation clavier)
- ✅ **Compatible RGPD** (politique de confidentialité, mentions légales)
- ✅ **Animations fluides** (défilement, apparition au scroll, carrousel de témoignages)
- ✅ **Bouton WhatsApp flottant** pour contact rapide
- ✅ **Formulaires interactifs** avec validation côté client

---

## 📁 Structure des fichiers

```
ifpf-website/
│
├── index.html                     → Page d'accueil
├── presentation.html              → Présentation de l'institut
├── formations.html                → 4 formations détaillées
├── apprentissage.html             → Alternance + candidature
├── entreprise.html                → Espace entreprises
├── actualites.html                → Actualités / blog
├── contact.html                   → Contact + carte + formulaire
├── mentions-legales.html          → Mentions légales obligatoires
├── politique-confidentialite.html → Conformité RGPD
│
├── css/
│   └── style.css                  → Feuille de style unique (~2100 lignes)
│
├── js/
│   └── script.js                  → Menu burger, carrousel, animations, formulaires
│
├── images/                        → Dossier réservé pour vos photos
│
└── README.md                      → Ce fichier
```

---

## 📄 Pages du site

| Page | URL | Description |
|------|-----|-------------|
| Accueil | `index.html` | Hero, stats, 4 formations, valeurs, témoignages, CTA |
| L'Institut | `presentation.html` | Présentation, équipements, méthodes, 6 valeurs |
| Formations | `formations.html` | 4 cartes détaillées (objectifs, compétences, débouchés) |
| Apprentissage | `apprentissage.html` | Alternance + formulaire de candidature |
| Entreprises | `entreprise.html` | Recruter, devenir partenaire, déposer une offre |
| Actualités | `actualites.html` | Grille d'articles + sidebar |
| Contact | `contact.html` | Formulaire, coordonnées, carte OpenStreetMap |
| Mentions légales | `mentions-legales.html` | Informations légales |
| Confidentialité | `politique-confidentialite.html` | RGPD, droits, cookies |

---

## 🚀 Hébergement sur LWS (guide complet)

### Étape 1 — Préparer votre hébergement LWS

1. Connectez-vous à votre [espace client LWS](https://panel.lws.fr).
2. Si ce n'est pas déjà fait, commandez un pack d'hébergement **LWS Perso**, **LWS Pro** ou supérieur.
3. Commandez et configurez votre nom de domaine (ex : `ifpf.fr` ou `ifpf.com`).

### Étape 2 — Récupérer vos identifiants FTP

Dans votre espace client LWS :

1. Allez dans **Mes Services → Hébergement Web → Gérer**.
2. Cliquez sur **Accès FTP / SSH**.
3. Notez :
   - **Serveur (hôte)** : ex. `ftp.ifpf.fr` ou `ftp.votredomaine.com`
   - **Nom d'utilisateur FTP**
   - **Mot de passe FTP**
   - **Port** : `21` (FTP) ou `22` (SFTP, recommandé)

### Étape 3 — Uploader les fichiers via FTP

**Option A — Avec FileZilla (recommandé, gratuit) :**

1. Téléchargez FileZilla : [https://filezilla-project.org](https://filezilla-project.org)
2. Ouvrez FileZilla → **Fichier → Gestionnaire de sites → Nouveau site**
3. Renseignez :
   - **Hôte** : `ftp.votredomaine.com`
   - **Protocole** : `SFTP` (ou FTP si non disponible)
   - **Type d'authentification** : `Normale`
   - **Identifiant / Mot de passe** : ceux fournis par LWS
4. Cliquez sur **Connexion**.
5. Dans le panneau de droite (serveur distant), naviguez vers le dossier racine de votre site. Selon votre offre LWS, cela peut être :
   - `/` (racine directe)
   - `/www/`
   - `/public_html/`
   - `/htdocs/`
6. Sélectionnez **TOUS les fichiers et dossiers** du dossier `ifpf-website` en local (panneau gauche) :
   - `index.html`
   - `presentation.html`
   - `formations.html`
   - `apprentissage.html`
   - `entreprise.html`
   - `actualites.html`
   - `contact.html`
   - `mentions-legales.html`
   - `politique-confidentialite.html`
   - dossier `css/`
   - dossier `js/`
   - dossier `images/`
7. **Glissez-déposez** vers le serveur distant.
8. Attendez que le transfert soit terminé (quelques secondes à quelques minutes).

**Option B — Via le Gestionnaire de fichiers LWS :**

1. Dans l'espace client LWS, allez dans **Gérer → Fichiers**.
2. Naviguez vers la racine de votre site (`/www/` ou équivalent).
3. Cliquez sur **Téléverser**.
4. Pour simplifier, **compressez d'abord le dossier `ifpf-website` en `.zip`** sur votre ordinateur, puis uploadez le ZIP et utilisez l'option **Extraire** du gestionnaire de fichiers LWS.

### Étape 4 — Vérifier la mise en ligne

1. Ouvrez votre navigateur et tapez votre nom de domaine : `https://www.ifpf.fr` (ou le vôtre).
2. La page d'accueil doit s'afficher.
3. Testez toutes les pages en naviguant via le menu.
4. Testez sur mobile (vérifiez que le menu burger fonctionne).
5. Testez le bouton WhatsApp flottant en bas à droite.

### Étape 5 — Activer le certificat SSL (HTTPS)

LWS fournit un certificat SSL **Let's Encrypt gratuit** :

1. Dans votre espace LWS → **Mon hébergement → SSL**.
2. Activez le **certificat SSL gratuit Let's Encrypt** sur votre domaine.
3. Une fois activé (quelques minutes), forcez la redirection HTTP → HTTPS :
   - Dans **Mon hébergement → Paramètres**, activez **Redirection HTTPS**.
4. Vérifiez en tapant `https://www.ifpf.fr` : un **cadenas vert** doit apparaître.

### Étape 6 — Configuration finale recommandée

- **Mettre en place une redirection `www` → domaine principal** (ou l'inverse) pour éviter les doublons SEO.
- **Ajouter un fichier `.htaccess`** à la racine pour :
  - Compression GZIP (performance)
  - Mise en cache navigateur
  - Règles de réécriture propres

Exemple de `.htaccess` minimal à placer à la racine :

```apache
# Forcer HTTPS
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Compression GZIP
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/css text/javascript application/javascript
</IfModule>

# Cache navigateur
<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType text/css "access plus 1 month"
  ExpiresByType application/javascript "access plus 1 month"
  ExpiresByType image/jpeg "access plus 6 months"
  ExpiresByType image/png "access plus 6 months"
  ExpiresByType image/svg+xml "access plus 6 months"
</IfModule>
```

---

## 🎨 Personnalisation du site

### Modifier les couleurs

Ouvrez `css/style.css` et cherchez la section `:root` (début du fichier). Modifiez les variables CSS :

```css
:root {
  --bleu-france: #0055A4;
  --bleu-france-fonce: #003F7D;
  --rouge-france: #EF4135;
  --rouge-france-fonce: #C8301F;
  --blanc: #FFFFFF;
  --blanc-casse: #F8F9FC;
  /* ... */
}
```

### Modifier les coordonnées de contact

Les coordonnées se trouvent dans **chaque page HTML** (footer) et dans **contact.html**. Faites une recherche/remplacer dans tous les fichiers `.html` :

- `123 Avenue de la République` → votre adresse
- `75011 Paris` → votre ville
- `+33 (0)1 23 45 67 89` → votre téléphone
- `contact@ifpf.fr` → votre email
- `wa.me/33123456789` → votre numéro WhatsApp (format international sans +)

### Modifier la carte de localisation

Dans `contact.html`, cherchez la balise `<iframe>` :

```html
<iframe src="https://www.openstreetmap.org/export/embed.html?bbox=...">
```

Allez sur [openstreetmap.org](https://www.openstreetmap.org), recherchez votre adresse, cliquez sur **Partager → HTML** et copiez le code iframe.

### Ajouter des images

Placez vos images dans le dossier `images/` puis référencez-les dans vos pages HTML :

```html
<img src="images/mon-image.jpg" alt="Description">
```

**Recommandations :**
- Format : `.webp` (préféré) ou `.jpg` pour les photos, `.svg` pour les logos/icônes
- Poids : max 200 Ko par image (utilisez [TinyPNG](https://tinypng.com) pour compresser)
- Dimensions adaptées : 1920×1080 pour hero, 800×600 pour formations

### Remplacer le logo

Le logo actuel est un logo textuel "IF" stylisé dans une div. Pour le remplacer par une image :

1. Placez votre logo dans `images/logo.svg` ou `images/logo.png`.
2. Dans **chaque page HTML**, remplacez :

```html
<div class="logo-icone">IF</div>
```

par :

```html
<img src="images/logo.svg" alt="Logo IFPF" class="logo-icone">
```

---

## 🛠️ Maintenance & mises à jour

### Ajouter un nouvel article d'actualité

Ouvrez `actualites.html`, repérez la classe `articles-grille`, et dupliquez un bloc `<article class="carte-article animer">`. Modifiez le titre, la date, la catégorie et le texte.

### Ajouter une nouvelle formation

Ouvrez `formations.html`, repérez un bloc `<article class="formation-carte-detail">`, dupliquez-le, changez l'ID et le numéro. Pensez aussi à ajouter le lien dans **toutes les navigations** (header et footer) de **toutes les pages**.

### Connecter le formulaire de contact à un vrai envoi d'email

Les formulaires sont actuellement en **mode démonstration** (`onsubmit="event.preventDefault(); alert(...)"`).

Pour connecter à un vrai envoi :

**Option 1 — FormSubmit (le plus simple, gratuit) :**

Modifiez la balise `<form>` :

```html
<form action="https://formsubmit.co/contact@ifpf.fr" method="POST">
```

**Option 2 — Script PHP côté LWS :**

Créez un fichier `envoi.php` à la racine et reliez le formulaire. LWS prend en charge PHP nativement.

### Sauvegarde

Conservez une copie du dossier `ifpf-website/` complet sur votre ordinateur et/ou sur un disque externe. Avant toute modification majeure, faites un backup.

---

## 💬 Support

### Contacts utiles

- **Support LWS** : [https://aide.lws.fr](https://aide.lws.fr) — Tel : +33 (0)1 77 62 30 03
- **Panel client LWS** : [https://panel.lws.fr](https://panel.lws.fr)
- **Documentation FileZilla** : [https://wiki.filezilla-project.org](https://wiki.filezilla-project.org)

### Problèmes fréquents

**Le site s'affiche mal après l'upload :**
→ Vérifiez que le dossier `css/` et le fichier `css/style.css` ont bien été transférés. C'est la cause n°1.

**Les liens entre pages ne fonctionnent pas :**
→ Tous les fichiers HTML doivent être à la racine (pas dans un sous-dossier).

**La page blanche s'affiche :**
→ Le fichier `index.html` n'est peut-être pas à la racine. Vérifiez que c'est bien la première page trouvée par le serveur.

**Le HTTPS n'est pas actif :**
→ L'activation Let's Encrypt peut prendre 15 à 30 minutes après la demande.

**Le bouton WhatsApp ne s'ouvre pas :**
→ Vérifiez que le numéro dans le lien `wa.me/33...` est au format international **sans espaces ni signe +**.

---

## 📜 Licence

Ce site a été conçu spécifiquement pour l'**Institut de Formation Professionnelle de France (IFPF)**. Tous droits réservés © 2026 IFPF.

---

**🇫🇷 Fait avec excellence et savoir-faire français.**
